Jack Martinez
N18522789

Twitter clone that has the ability to make accounts, login, logout, and delete 
user accounts. Users who are logged in can make posts, but not delete posts.
Users can also choose who they follow, and they can also choose to unfollow 
someone they no longer wish to see updates about

Run Notes:
	-I always ran using "go run main.go"
	-all the html files should be in the same directory as main.go

